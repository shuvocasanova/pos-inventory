<?php 

class ControllerTemplate{
	public function ctrTemplate(){
		include "views/template.php";
	}


}