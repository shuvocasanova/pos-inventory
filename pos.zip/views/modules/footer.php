<footer class="main-footer">
	<strong>Copyright &copy; 2019 By Shuvo Kumer Das..  <a href="https://github.com/shuvocasanova" target="_blank">Visit my github page</a>
	</strong>
	All rights reserved
</footer>